<?php

namespace Mpdf\Tag;

class Q extends InlineTag
{


}
